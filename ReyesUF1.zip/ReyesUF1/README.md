PHPM07
=======

Ejercicios de PHP 

Probando el control de versiones y sourcetree

--

Funcionalitats

- Crear persona

- Crear projecte

- Afegir persona a projecte

- Donat un projecte, eliminar una (o unes) determinada(s) persona(s) del projecte. NO eliminem la persona de la BD, només del projecte.

- Llistar projectes i els seus components (al final d'aquest llistat es mostraran les persones sense projecte)

 

Entrega:

CognomAlumneUF1.zip conté una carpeta amb el cognom de l'alumne i entre d'altres fitxers té:

bd.sql : script creació BD, ha de tenir un parell de projectes i 3 persones

          nom BD: cognomAlumne; Usuari:root, pwd:""

index.php/html : pàgina inicial o hi ha un enllaç a cadascuna de les funcionalitats.

L'incompliment d'aquests normés implicarà que no es corregirà.
