<?php 
	/*
	* Funcion que recibe las personas a añadir a un proyecto y lo actualiza
	* en la BBDD
	*
	* Autor: Joaquín Reyes Lettieri
	* Fecha: 18.01.14
	* Version: 1.0
	*
	*/
 ?>
 <?php require_once('funciones.php'); ?>
 
 <!doctype html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>Add.php</title>
	<link rel="stylesheet" href="style.css">
 </head>
 <body>
	 <div class="msj">
	 	 <?php add(); ?>
 	 	<?php menu(); ?>
	 </div>
 </body>
 </html>

