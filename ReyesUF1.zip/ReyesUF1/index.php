<?php 
	/*
	* Ejercicio Gestion de proyectos.
	* 
	* Autor: Joaquín Reyes Lettieri
	* Fecha: 17.01.14
	* Version: 1.0
	*/
 ?>
<?php require_once('funciones.php'); ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Indice</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="wrap">
		<h1>Gestion de proyectos</h1>
		<?php menu(); ?>
	</div>
</body>
</html>